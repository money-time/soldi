<?php
	require 'settings_path.php';
	require _TRACK_SHOW_COMMON_PATH . '/process_clicks.php';
?>