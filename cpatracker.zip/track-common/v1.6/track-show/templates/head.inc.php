<?php if (!$include_flag){exit();} ?>
<meta charset="utf-8">
<title>CPA Tracker<?php if($_GET['page'] == 'support') echo ' 1.6'; ?></title>    
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-FRAME-OPTIONS" content="DENY">
<link href="<?php echo _HTML_LIB_PATH;?>/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link rel="stylesheet" href="<?php echo _HTML_LIB_PATH;?>/font-awesome/css/font-awesome.min.css">
<link href="<?php echo _HTML_TEMPLATE_PATH;?>/css/main.css" rel="stylesheet">
<!--[if lt IE 9]>
  <script src="<?php echo _HTML_LIB_PATH;?>/bootstrap/js/html5shiv.js"></script>
  <script src="<?php echo _HTML_LIB_PATH;?>/bootstrap/js/respond.min.js"></script>
<![endif]-->
<script src="<?php echo _HTML_LIB_PATH;?>/jquery/1.11.1/jquery.min.js"></script>
<script src="<?php echo _HTML_LIB_PATH;?>/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo _HTML_LIB_PATH;?>/uploader/uploader.min.js"></script>
