<?php if (!$include_flag){exit();} ?>

<div class="container">
	<div class="row credit">
		<?php
		if ($bHideBottomMenu!==true){
		?>
			<span class="pull-right"><a href="?page=support">Поддержка</a></span>
		<?php
		}
		?>
	</div>
</div>