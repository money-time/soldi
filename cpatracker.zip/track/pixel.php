<?php
	require "settings_path.php";
	require _TRACK_COMMON_PATH."/pixel.php";
?>